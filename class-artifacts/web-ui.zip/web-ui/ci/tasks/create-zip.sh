#!/bin/bash

cd source

zip -r web-ui.zip web-ui

cp web-ui.zip ../artifacts/web-ui.zip
