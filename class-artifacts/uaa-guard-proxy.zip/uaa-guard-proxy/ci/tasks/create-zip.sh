#!/bin/bash

cd source

zip -r uaa-guard-proxy.zip uaa-guard-proxy

cp uaa-guard-proxy.zip ../artifacts/uaa-guard-proxy.zip
